# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(endianness-check src/endianness-check.cpp)
set_property(TARGET endianness-check PROPERTY CXX_STANDARD 11)
target_link_libraries(endianness-check lionss pthread)

add_executable(meson-build src/meson-build.cpp)
set_property(TARGET meson-build PROPERTY CXX_STANDARD 11)
target_link_libraries(meson-build lionss pthread)

add_executable(lizard-complexity src/lizard-complexity.cpp)
set_property(TARGET lizard-complexity PROPERTY CXX_STANDARD 11)
target_link_libraries(lizard-complexity lionss pthread)

add_executable(decoder-fuzz src/decoder-fuzz.cpp)
set_property(TARGET decoder-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(decoder-fuzz lionss pthread)

add_executable(crash-handler-test src/crash-handler-test.cpp)
set_property(TARGET crash-handler-test PROPERTY CXX_STANDARD 11)
target_link_libraries(crash-handler-test lionss pthread)

add_executable(symbol-count src/symbol-count.cpp)
set_property(TARGET symbol-count PROPERTY CXX_STANDARD 11)
target_link_libraries(symbol-count lionss pthread)

add_executable(cxx20-modules src/cxx20-modules.cpp)
set_property(TARGET cxx20-modules PROPERTY CXX_STANDARD 11)
target_link_libraries(cxx20-modules lionss pthread)

add_executable(secrets-scan src/secrets-scan.cpp)
set_property(TARGET secrets-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(secrets-scan lionss pthread)

add_executable(latency-bench src/latency-bench.cpp)
set_property(TARGET latency-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(latency-bench lionss pthread)

add_executable(bloat-check src/bloat-check.cpp)
set_property(TARGET bloat-check PROPERTY CXX_STANDARD 11)
target_link_libraries(bloat-check lionss pthread)

add_executable(integration-tests src/integration-tests.cpp)
set_property(TARGET integration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(integration-tests lionss pthread)

add_executable(unused-includes src/unused-includes.cpp)
set_property(TARGET unused-includes PROPERTY CXX_STANDARD 11)
target_link_libraries(unused-includes lionss pthread)

add_executable(branch-coverage src/branch-coverage.cpp)
set_property(TARGET branch-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(branch-coverage lionss pthread)

add_executable(package-nsis src/package-nsis.cpp)
set_property(TARGET package-nsis PROPERTY CXX_STANDARD 11)
target_link_libraries(package-nsis lionss pthread)

add_executable(coverage-guided-fuzz src/coverage-guided-fuzz.cpp)
set_property(TARGET coverage-guided-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-guided-fuzz lionss pthread)

add_executable(sdist-build src/sdist-build.cpp)
set_property(TARGET sdist-build PROPERTY CXX_STANDARD 11)
target_link_libraries(sdist-build lionss pthread)

add_executable(afl-fuzz src/afl-fuzz.cpp)
set_property(TARGET afl-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(afl-fuzz lionss pthread)

add_executable(core-dump-test src/core-dump-test.cpp)
set_property(TARGET core-dump-test PROPERTY CXX_STANDARD 11)
target_link_libraries(core-dump-test lionss pthread)

add_executable(link-time-report src/link-time-report.cpp)
set_property(TARGET link-time-report PROPERTY CXX_STANDARD 11)
target_link_libraries(link-time-report lionss pthread)

add_executable(memory-profile src/memory-profile.cpp)
set_property(TARGET memory-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(memory-profile lionss pthread)

add_executable(migration-tests src/migration-tests.cpp)
set_property(TARGET migration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(migration-tests lionss pthread)

add_executable(valgrind-cachegrind src/valgrind-cachegrind.cpp)
set_property(TARGET valgrind-cachegrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-cachegrind lionss pthread)

add_executable(vendored-check src/vendored-check.cpp)
set_property(TARGET vendored-check PROPERTY CXX_STANDARD 11)
target_link_libraries(vendored-check lionss pthread)

add_executable(contention-bench src/contention-bench.cpp)
set_property(TARGET contention-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(contention-bench lionss pthread)

add_executable(asan-ubsan src/asan-ubsan.cpp)
set_property(TARGET asan-ubsan PROPERTY CXX_STANDARD 11)
target_link_libraries(asan-ubsan lionss pthread)

add_executable(package-dmg src/package-dmg.cpp)
set_property(TARGET package-dmg PROPERTY CXX_STANDARD 11)
target_link_libraries(package-dmg lionss pthread)

add_executable(offline-tests src/offline-tests.cpp)
set_property(TARGET offline-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(offline-tests lionss pthread)

add_executable(android-x86-64 src/android-x86-64.cpp)
set_property(TARGET android-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-x86-64 lionss pthread)

add_executable(fuzz-regression src/fuzz-regression.cpp)
set_property(TARGET fuzz-regression PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-regression lionss pthread)

add_executable(android-armv7 src/android-armv7.cpp)
set_property(TARGET android-armv7 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-armv7 lionss pthread)

