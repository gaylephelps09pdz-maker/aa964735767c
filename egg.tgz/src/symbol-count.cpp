// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("symbol count"); }
int main(){
  announce();
  return lionss_run_workload("symbol-count");
}
