// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("offline tests"); }
int main(){
  announce();
  return lionss_run_workload("offline-tests");
}
