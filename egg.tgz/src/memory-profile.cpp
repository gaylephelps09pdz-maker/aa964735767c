// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "memory profile");
  std::fflush(stdout);
  return lionss_run_workload("memory-profile");
}
