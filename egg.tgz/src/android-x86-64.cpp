// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("android x86 64\n", stdout);
  return lionss_run_workload("android-x86-64");
}
